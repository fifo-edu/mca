
-- Categorias iniciais
INSERT INTO categories (name, slug, icon) VALUES
('Supermercado','supermercado','🛒'),
('Alimentação','alimentacao','🍴'),
('Casa e Decoração','casa-decoracao','🏠'),
('Beleza e Saúde','beleza-saude','💜'),
('Moda','moda','👕'),
('Eletrônicos','eletronicos','📱'),
('Pet','pet','🐾'),
('Serviços','servicos','🔧'),
('Esportes','esportes','⚽'),
('Auto e Moto','auto-moto','🚙')
ON CONFLICT (slug) DO NOTHING;

-- Observação:
-- Usuários devem ser criados pela API para que as senhas sejam armazenadas
-- com hash bcrypt. Depois disso, lojas e produtos podem ser cadastrados
-- pela própria interface do Minha Cidade Aqui.
