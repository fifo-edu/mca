import fs from "fs";
import path from "path";
import pg from "pg";
import dotenv from "dotenv";
import { fileURLToPath } from "url";

dotenv.config();
const { Client } = pg;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL não definida.");
  process.exit(1);
}

const client = new Client({ connectionString: process.env.DATABASE_URL });

try {
  await client.connect();
  const sql = fs.readFileSync(path.join(__dirname, "seed_test_data.sql"), "utf8");
  console.log("[DB] Inserindo dados fictícios...");
  await client.query(sql);
  console.log("[DB] Dados fictícios inseridos com sucesso.");
} catch (error) {
  console.error("[DB] Erro:", error.message);
  process.exitCode = 1;
} finally {
  await client.end().catch(() => {});
}
