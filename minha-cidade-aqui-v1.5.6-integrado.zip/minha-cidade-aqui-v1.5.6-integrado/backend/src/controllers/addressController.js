import { pool } from "../config/db.js";

export async function myAddresses(req, res) {
  try {
    const result = await pool.query(
      `SELECT id, label, cep, street, number, complement, district,
              city, state, latitude, longitude, is_default, created_at
       FROM addresses
       WHERE user_id = $1
       ORDER BY is_default DESC, created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar endereços." });
  }
}

export async function createAddress(req, res) {
  try {
    const {
      label, cep, street, number, complement, district,
      city, state = "SP", latitude, longitude
    } = req.body;

    if (!street || !city) {
      return res.status(400).json({ error: "Rua e cidade são obrigatórias." });
    }

    const count = await pool.query(
      "SELECT COUNT(*)::int AS total FROM addresses WHERE user_id = $1",
      [req.user.id]
    );

    const isDefault = count.rows[0].total === 0;

    const result = await pool.query(
      `INSERT INTO addresses
       (user_id, label, cep, street, number, complement, district,
        city, state, latitude, longitude, is_default)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
       RETURNING *`,
      [
        req.user.id, label || null, cep || null, street,
        number || null, complement || null, district || null,
        city, state, latitude || null, longitude || null, isDefault
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao salvar endereço." });
  }
}

export async function setDefaultAddress(req, res) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const owned = await client.query(
      "SELECT id FROM addresses WHERE id = $1 AND user_id = $2",
      [req.params.id, req.user.id]
    );

    if (!owned.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Endereço não encontrado." });
    }

    await client.query("UPDATE addresses SET is_default = FALSE WHERE user_id = $1", [req.user.id]);
    const result = await client.query(
      `UPDATE addresses SET is_default = TRUE
       WHERE id = $1 AND user_id = $2
       RETURNING *`,
      [req.params.id, req.user.id]
    );

    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);
    res.status(500).json({ error: "Erro ao definir endereço padrão." });
  } finally {
    client.release();
  }
}

export async function deleteAddress(req, res) {
  try {
    const result = await pool.query(
      `DELETE FROM addresses
       WHERE id = $1 AND user_id = $2
       RETURNING id, is_default`,
      [req.params.id, req.user.id]
    );

    if (!result.rowCount) return res.status(404).json({ error: "Endereço não encontrado." });

    if (result.rows[0].is_default) {
      const next = await pool.query(
        `SELECT id FROM addresses
         WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
        [req.user.id]
      );
      if (next.rowCount) {
        await pool.query("UPDATE addresses SET is_default = TRUE WHERE id = $1", [next.rows[0].id]);
      }
    }

    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao excluir endereço." });
  }
}
