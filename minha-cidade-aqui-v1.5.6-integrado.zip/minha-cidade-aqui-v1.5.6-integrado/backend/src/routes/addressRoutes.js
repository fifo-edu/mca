import { Router } from "express";
import { createAddress, deleteAddress, myAddresses, setDefaultAddress } from "../controllers/addressController.js";
import { allowRoles, authRequired } from "../middlewares/auth.js";

const router = Router();

router.get("/my", authRequired, allowRoles("customer"), myAddresses);
router.post("/", authRequired, allowRoles("customer"), createAddress);
router.patch("/:id/default", authRequired, allowRoles("customer"), setDefaultAddress);
router.delete("/:id", authRequired, allowRoles("customer"), deleteAddress);

export default router;
