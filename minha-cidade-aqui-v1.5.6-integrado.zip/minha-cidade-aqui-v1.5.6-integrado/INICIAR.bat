@echo off
cd /d "%~dp0backend"
if not exist node_modules (
  echo Instalando dependencias...
  call npm install
)
if not exist .env (
  echo.
  echo Arquivo .env ainda nao existe.
  echo Copiando .env.example para .env...
  copy .env.example .env >nul
  echo Abra backend\.env e informe sua senha do PostgreSQL antes de continuar.
  notepad .env
  pause
)
echo.
echo Iniciando Minha Cidade Aqui V1.5.6...
call npm run dev
