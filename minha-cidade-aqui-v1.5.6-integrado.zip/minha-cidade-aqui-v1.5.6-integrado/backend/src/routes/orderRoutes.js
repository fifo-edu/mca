import { Router } from "express";
import { createOrder, merchantOrders, myOrders, updateOrderStatus, availableDriverOrders, myDriverOrders, acceptDriverOrder, updateDriverOrderStatus } from "../controllers/orderController.js";
import { allowRoles, authRequired } from "../middlewares/auth.js";

const router = Router();

router.post("/", authRequired, allowRoles("customer"), createOrder);
router.get("/my", authRequired, allowRoles("customer"), myOrders);
router.get("/merchant", authRequired, allowRoles("merchant"), merchantOrders);
router.get("/driver/available", authRequired, allowRoles("driver"), availableDriverOrders);
router.get("/driver/my", authRequired, allowRoles("driver"), myDriverOrders);
router.patch("/driver/:id/accept", authRequired, allowRoles("driver"), acceptDriverOrder);
router.patch("/driver/:id/status", authRequired, allowRoles("driver"), updateDriverOrderStatus);
router.patch("/:id/status", authRequired, allowRoles("merchant"), updateOrderStatus);

export default router;
