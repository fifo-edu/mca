import dotenv from "dotenv";
import { pool, checkDatabase } from "../src/config/db.js";

dotenv.config();

try {
  const info = await checkDatabase();

  const tables = await pool.query(`
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name IN (
        'users','addresses','stores','categories','products',
        'orders','order_items','favorites','deliveries'
      )
    ORDER BY table_name
  `);

  console.log("[DB] Conexão OK");
  console.log("[DB] Banco:", info.database);
  console.log("[DB] Usuário:", info.user_name);
  console.log("[DB] Tabelas:", tables.rows.map(r => r.table_name).join(", "));
} catch (error) {
  console.error("[DB] Falha:", error.message);
  process.exitCode = 1;
} finally {
  await pool.end().catch(() => {});
}
