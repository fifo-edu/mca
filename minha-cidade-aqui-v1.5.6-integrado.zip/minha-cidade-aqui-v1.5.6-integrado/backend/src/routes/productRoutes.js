import { Router } from "express";
import { createProduct, listProducts, myProducts, updateProduct } from "../controllers/productController.js";
import { allowRoles, authRequired } from "../middlewares/auth.js";

const router = Router();

router.get("/", listProducts);
router.get("/mine", authRequired, allowRoles("merchant"), myProducts);
router.post("/", authRequired, allowRoles("merchant"), createProduct);
router.patch("/:id", authRequired, allowRoles("merchant"), updateProduct);

export default router;
