MINHA CIDADE AQUI - V1.4 INTEGRADO
=================================

Esta versão une:
- Frontend oficial aprovado (hero preservado, sem os 3 traços)
- Backend Node.js + Express
- PostgreSQL
- Rotas de catálogo, login/cadastro, lojista, cliente, endereços e pedidos

COMO INSTALAR
-------------
1) Abra a pasta backend no CMD.
2) Execute: npm install
3) Execute: copy .env.example .env
4) Execute: notepad .env
5) No arquivo .env, troque somente DB_PASSWORD=SUA_SENHA_AQUI pela sua senha real do PostgreSQL.
6) Salve e feche o Bloco de Notas.
7) Execute: npm run dev
8) Deixe o CMD aberto.
9) Abra no navegador: http://localhost:3000
10) Teste técnico: http://localhost:3000/api/health

IMPORTANTE
----------
O banco esperado é: minha_cidade_aqui
O PostgreSQL deve estar rodando.
O frontend agora usa /api no mesmo servidor; não é necessário abrir o HTML separadamente.
