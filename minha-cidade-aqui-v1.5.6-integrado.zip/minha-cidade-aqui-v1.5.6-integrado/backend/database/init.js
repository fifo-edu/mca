import fs from "fs";
import path from "path";
import pg from "pg";
import dotenv from "dotenv";
import { fileURLToPath } from "url";

dotenv.config();

const { Client } = pg;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL não definida no .env");
  process.exit(1);
}

const client = new Client({ connectionString: process.env.DATABASE_URL });

try {
  await client.connect();

  const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  const seed = fs.readFileSync(path.join(__dirname, "seed.sql"), "utf8");

  console.log("[DB] Aplicando schema...");
  await client.query(schema);

  console.log("[DB] Aplicando seed...");
  await client.query(seed);

  console.log("[DB] Inicialização concluída.");
} catch (error) {
  console.error("[DB] Falha na inicialização:", error.message);
  process.exitCode = 1;
} finally {
  await client.end().catch(() => {});
}
