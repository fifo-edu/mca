import { envPath, envStatus } from "./config/env.js";
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

import authRoutes from "./routes/authRoutes.js";
import storeRoutes from "./routes/storeRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";
import addressRoutes from "./routes/addressRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import { pool, checkDatabase } from "./config/db.js";

const app = express();
const port = Number(process.env.PORT || 3000);
console.log(`Arquivo .env: ${envStatus.envFileFound ? "encontrado" : "NÃO encontrado"} (${envPath})`);
if (!envStatus.dbPasswordConfigured) {
  console.warn("AVISO: DB_PASSWORD não configurado no .env.");
}
if (!envStatus.jwtSecretConfigured) {
  console.warn("AVISO: JWT_SECRET não configurado no .env. Login não funcionará.");
}
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.resolve(__dirname, "../public");

app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", async (req, res) => {
  try {
    const db = await checkDatabase();
    const counts = await pool.query(`
      SELECT
        (SELECT COUNT(*)::int FROM users) AS users,
        (SELECT COUNT(*)::int FROM stores) AS stores,
        (SELECT COUNT(*)::int FROM products) AS products,
        (SELECT COUNT(*)::int FROM orders) AS orders
    `);
    res.json({
      api: "ok",
      database: "ok",
      service: "Minha Cidade Aqui API",
      version: "1.5.6",
      detalhes: {
        database: db.database,
        usuario: db.user_name,
        agora: db.server_time,
        registros: counts.rows[0]
      }
    });
  } catch (error) {
    res.status(503).json({
      api: "ok",
      database: "erro",
      version: "1.5.6",
      erro: error.message
    });
  }
});

app.use("/api/auth", authRoutes);
app.use("/api/stores", storeRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/addresses", addressRoutes);
app.use("/api/users", userRoutes);

app.use(express.static(publicDir));
app.get("/{*splat}", (req, res) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Rota não encontrada." });
  res.sendFile(path.join(publicDir, "index.html"));
});

app.listen(port, async () => {
  console.log(`Minha Cidade Aqui V1.5.6 rodando em http://localhost:${port}`);
  try {
    const db = await checkDatabase();
    console.log("PostgreSQL conectado com sucesso:", db);
  } catch (error) {
    console.error("Backend iniciou, mas não conectou ao PostgreSQL:", error.message);
  }
});
