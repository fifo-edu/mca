import pg from "pg";
import "./env.js";
const { Pool } = pg;

const sslEnabled = String(process.env.DB_SSL || "false").toLowerCase() === "true";

const poolConfig = process.env.DATABASE_URL
  ? {
      connectionString: process.env.DATABASE_URL,
      ssl: sslEnabled ? { rejectUnauthorized: false } : false
    }
  : {
      host: process.env.DB_HOST || "localhost",
      port: Number(process.env.DB_PORT || 5432),
      database: process.env.DB_NAME || "minha_cidade_aqui",
      user: process.env.DB_USER || "postgres",
      password: process.env.DB_PASSWORD,
      ssl: sslEnabled ? { rejectUnauthorized: false } : false
    };

export const pool = new Pool({
  ...poolConfig,
  max: Number(process.env.DB_POOL_MAX || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

pool.on("error", (error) => {
  console.error("[DB] Erro inesperado no pool PostgreSQL:", error.message);
});

export async function checkDatabase() {
  const result = await pool.query(`
    SELECT current_database() AS database,
           current_user AS user_name,
           NOW() AS server_time
  `);
  return result.rows[0];
}
