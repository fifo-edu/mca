import "../config/env.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { pool } from "../config/db.js";

export async function register(req, res) {
  try {
    const { name, email, password, role = "customer" } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: "Nome, e-mail e senha são obrigatórios." });
    }

    const allowedRoles = ["customer", "merchant", "driver"];
    if (!allowedRoles.includes(role)) {
      return res.status(400).json({ error: "Perfil inválido." });
    }

    const exists = await pool.query(
      "SELECT id FROM users WHERE email = $1",
      [email.toLowerCase()]
    );

    if (exists.rowCount) {
      return res.status(409).json({ error: "E-mail já cadastrado." });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const result = await pool.query(
      `INSERT INTO users (name, email, password_hash, role)
       VALUES ($1, $2, $3, $4)
       RETURNING id, name, email, role, created_at`,
      [name, email.toLowerCase(), passwordHash, role]
    );

    return res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Erro interno ao cadastrar usuário." });
  }
}

export async function login(req, res) {
  try {
    const { email, password } = req.body;

    const result = await pool.query(
      `SELECT id, name, email, password_hash, role, is_active
       FROM users WHERE email = $1`,
      [email?.toLowerCase()]
    );

    if (!result.rowCount) {
      return res.status(401).json({ error: "E-mail ou senha inválidos." });
    }

    const user = result.rows[0];

    if (!user.is_active) {
      return res.status(403).json({ error: "Usuário inativo." });
    }

    const ok = await bcrypt.compare(password || "", user.password_hash);

    if (!ok) {
      return res.status(401).json({ error: "E-mail ou senha inválidos." });
    }

    const jwtSecret = process.env.JWT_SECRET?.trim();
    if (!jwtSecret) {
      console.error("JWT_SECRET não foi carregado do arquivo .env.");
      return res.status(500).json({ error: "JWT_SECRET não configurado no servidor." });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, email: user.email },
      jwtSecret,
      { expiresIn: "8h" }
    );

    return res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: "Erro interno ao autenticar." });
  }
}
