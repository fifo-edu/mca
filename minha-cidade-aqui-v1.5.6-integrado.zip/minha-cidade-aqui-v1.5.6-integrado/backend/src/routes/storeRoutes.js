import { Router } from "express";
import { createStore, getStore, listStores, myStores, updateStore } from "../controllers/storeController.js";
import { allowRoles, authRequired } from "../middlewares/auth.js";

const router = Router();

router.get("/", listStores);
router.get("/mine", authRequired, allowRoles("merchant"), myStores);
router.get("/:id", getStore);
router.post("/", authRequired, allowRoles("merchant"), createStore);
router.patch("/:id", authRequired, allowRoles("merchant"), updateStore);

export default router;
