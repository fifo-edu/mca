-- MINHA CIDADE AQUI - DADOS FICTÍCIOS DE TESTE V1.2
-- Senha padrão de todas as contas de teste: Teste123!
BEGIN;

DELETE FROM deliveries;
DELETE FROM favorites;
DELETE FROM order_items;
DELETE FROM orders;
DELETE FROM products;
DELETE FROM stores;
DELETE FROM addresses;
DELETE FROM users WHERE email LIKE '%@teste.minhacidadeaqui.com.br';
DELETE FROM categories;

INSERT INTO categories (name, slug, icon) VALUES
('Supermercado','supermercado','🛒'),
('Alimentação','alimentacao','🍴'),
('Casa e Decoração','casa-decoracao','🏠'),
('Beleza e Saúde','beleza-saude','💜'),
('Moda','moda','👕'),
('Eletrônicos','eletronicos','📱'),
('Pet','pet','🐾'),
('Serviços','servicos','🔧'),
('Esportes','esportes','⚽'),
('Auto e Moto','auto-moto','🚙')
ON CONFLICT (slug) DO UPDATE SET name=EXCLUDED.name, icon=EXCLUDED.icon;

INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Administrador Teste','admin@teste.minhacidadeaqui.com.br','(11) 99999-0000',crypt('Teste123!', gen_salt('bf',10)),'admin')
ON CONFLICT (email) DO NOTHING;


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Ana Clara Silva','ana.clara@teste.minhacidadeaqui.com.br','(11) 99001-0001',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200001','Rua Teste 1','101','Bairro Teste 1','Jundiaí','SP',TRUE
FROM users WHERE email='ana.clara@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Bruno Santos','bruno.santos@teste.minhacidadeaqui.com.br','(11) 99001-0002',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200002','Rua Teste 2','102','Bairro Teste 2','Jundiaí','SP',TRUE
FROM users WHERE email='bruno.santos@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Carla Oliveira','carla.oliveira@teste.minhacidadeaqui.com.br','(11) 99001-0003',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200003','Rua Teste 3','103','Bairro Teste 3','Jundiaí','SP',TRUE
FROM users WHERE email='carla.oliveira@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Daniel Costa','daniel.costa@teste.minhacidadeaqui.com.br','(11) 99001-0004',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200004','Rua Teste 4','104','Bairro Teste 4','Jundiaí','SP',TRUE
FROM users WHERE email='daniel.costa@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Eduarda Lima','eduarda.lima@teste.minhacidadeaqui.com.br','(11) 99001-0005',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200005','Rua Teste 5','105','Bairro Teste 5','Jundiaí','SP',TRUE
FROM users WHERE email='eduarda.lima@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Felipe Martins','felipe.martins@teste.minhacidadeaqui.com.br','(11) 99001-0006',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200006','Rua Teste 6','106','Bairro Teste 1','Jundiaí','SP',TRUE
FROM users WHERE email='felipe.martins@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Gabriela Rocha','gabriela.rocha@teste.minhacidadeaqui.com.br','(11) 99001-0007',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200007','Rua Teste 7','107','Bairro Teste 2','Jundiaí','SP',TRUE
FROM users WHERE email='gabriela.rocha@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Henrique Alves','henrique.alves@teste.minhacidadeaqui.com.br','(11) 99001-0008',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200008','Rua Teste 8','108','Bairro Teste 3','Jundiaí','SP',TRUE
FROM users WHERE email='henrique.alves@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Isabela Mendes','isabela.mendes@teste.minhacidadeaqui.com.br','(11) 99001-0009',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200009','Rua Teste 9','109','Bairro Teste 4','Jundiaí','SP',TRUE
FROM users WHERE email='isabela.mendes@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('João Pedro Souza','joao.souza@teste.minhacidadeaqui.com.br','(11) 99001-0010',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200010','Rua Teste 10','110','Bairro Teste 5','Jundiaí','SP',TRUE
FROM users WHERE email='joao.souza@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Karen Ribeiro','karen.ribeiro@teste.minhacidadeaqui.com.br','(11) 99001-0011',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200011','Rua Teste 11','111','Bairro Teste 1','Jundiaí','SP',TRUE
FROM users WHERE email='karen.ribeiro@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Lucas Ferreira','lucas.ferreira@teste.minhacidadeaqui.com.br','(11) 99001-0012',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200012','Rua Teste 12','112','Bairro Teste 2','Jundiaí','SP',TRUE
FROM users WHERE email='lucas.ferreira@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Mariana Gomes','mariana.gomes@teste.minhacidadeaqui.com.br','(11) 99001-0013',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200013','Rua Teste 13','113','Bairro Teste 3','Jundiaí','SP',TRUE
FROM users WHERE email='mariana.gomes@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Nicolas Barros','nicolas.barros@teste.minhacidadeaqui.com.br','(11) 99001-0014',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200014','Rua Teste 14','114','Bairro Teste 4','Jundiaí','SP',TRUE
FROM users WHERE email='nicolas.barros@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Rafael Almeida','rafael.almeida@teste.minhacidadeaqui.com.br','(11) 99001-0015',crypt('Teste123!', gen_salt('bf',10)),'customer')
ON CONFLICT (email) DO NOTHING;

INSERT INTO addresses (user_id,label,cep,street,number,district,city,state,is_default)
SELECT id,'Casa','13200015','Rua Teste 15','115','Bairro Teste 5','Jundiaí','SP',TRUE
FROM users WHERE email='rafael.almeida@teste.minhacidadeaqui.com.br';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Diego Entregas','diego.driver@teste.minhacidadeaqui.com.br','(11) 99100-0001',crypt('Teste123!', gen_salt('bf',10)),'driver')
ON CONFLICT (email) DO NOTHING;


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Paulo Rápido','paulo.driver@teste.minhacidadeaqui.com.br','(11) 99100-0002',crypt('Teste123!', gen_salt('bf',10)),'driver')
ON CONFLICT (email) DO NOTHING;


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Renata Express','renata.driver@teste.minhacidadeaqui.com.br','(11) 99100-0003',crypt('Teste123!', gen_salt('bf',10)),'driver')
ON CONFLICT (email) DO NOTHING;


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Marcos Delivery','marcos.driver@teste.minhacidadeaqui.com.br','(11) 99100-0004',crypt('Teste123!', gen_salt('bf',10)),'driver')
ON CONFLICT (email) DO NOTHING;


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Lívia Entregas','livia.driver@teste.minhacidadeaqui.com.br','(11) 99100-0005',crypt('Teste123!', gen_salt('bf',10)),'driver')
ON CONFLICT (email) DO NOTHING;


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Mercado Vila Nova','lojista01@teste.minhacidadeaqui.com.br','(11) 99200-0001',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Mercado Vila Nova', 'mercado-vila-nova',
  'Empresa fictícia de teste da categoria Supermercado.',
  '(11) 99200-0001', 'contato@mercado-vila-nova.teste',
  '13210001', 'Avenida Comercial 1', '201',
  'Região 1', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='supermercado'
WHERE u.email='lojista01@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Café Especial 500g - Mercado Vila Nova',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  19.90, 22.88, 26, 'TST-010101', TRUE
FROM stores s
JOIN categories c ON c.slug='supermercado'
WHERE s.slug='mercado-vila-nova';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Cesta Essencial - Mercado Vila Nova',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  59.90, 68.88, 27, 'TST-010102', TRUE
FROM stores s
JOIN categories c ON c.slug='supermercado'
WHERE s.slug='mercado-vila-nova';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Empório Paulista','lojista02@teste.minhacidadeaqui.com.br','(11) 99200-0002',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Empório Paulista', 'emporio-paulista',
  'Empresa fictícia de teste da categoria Supermercado.',
  '(11) 99200-0002', 'contato@emporio-paulista.teste',
  '13210002', 'Avenida Comercial 2', '202',
  'Região 2', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='supermercado'
WHERE u.email='lojista02@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Cesta Essencial - Empório Paulista',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  59.90, 68.88, 31, 'TST-010201', TRUE
FROM stores s
JOIN categories c ON c.slug='supermercado'
WHERE s.slug='emporio-paulista';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Azeite Extra Virgem - Empório Paulista',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  34.90, 40.13, 32, 'TST-010202', TRUE
FROM stores s
JOIN categories c ON c.slug='supermercado'
WHERE s.slug='emporio-paulista';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Super Local Jundiaí','lojista03@teste.minhacidadeaqui.com.br','(11) 99200-0003',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Super Local Jundiaí', 'super-local-jundiai',
  'Empresa fictícia de teste da categoria Supermercado.',
  '(11) 99200-0003', 'contato@super-local-jundiai.teste',
  '13210003', 'Avenida Comercial 3', '203',
  'Região 3', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='supermercado'
WHERE u.email='lojista03@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Azeite Extra Virgem - Super Local Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  34.90, 40.13, 36, 'TST-010301', TRUE
FROM stores s
JOIN categories c ON c.slug='supermercado'
WHERE s.slug='super-local-jundiai';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Café Especial 500g - Super Local Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  19.90, 22.88, 37, 'TST-010302', TRUE
FROM stores s
JOIN categories c ON c.slug='supermercado'
WHERE s.slug='super-local-jundiai';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Pizzaria Bela Praça','lojista04@teste.minhacidadeaqui.com.br','(11) 99200-0004',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Pizzaria Bela Praça', 'pizzaria-bela-praca',
  'Empresa fictícia de teste da categoria Alimentação.',
  '(11) 99200-0004', 'contato@pizzaria-bela-praca.teste',
  '13210004', 'Avenida Comercial 4', '204',
  'Região 4', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='alimentacao'
WHERE u.email='lojista04@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Pizza Margherita - Pizzaria Bela Praça',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  38.90, 44.73, 26, 'TST-020101', TRUE
FROM stores s
JOIN categories c ON c.slug='alimentacao'
WHERE s.slug='pizzaria-bela-praca';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Lanche Artesanal - Pizzaria Bela Praça',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  29.90, 34.38, 27, 'TST-020102', TRUE
FROM stores s
JOIN categories c ON c.slug='alimentacao'
WHERE s.slug='pizzaria-bela-praca';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Sabor da Serra','lojista05@teste.minhacidadeaqui.com.br','(11) 99200-0005',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Sabor da Serra', 'sabor-da-serra',
  'Empresa fictícia de teste da categoria Alimentação.',
  '(11) 99200-0005', 'contato@sabor-da-serra.teste',
  '13210005', 'Avenida Comercial 5', '205',
  'Região 5', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='alimentacao'
WHERE u.email='lojista05@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Lanche Artesanal - Sabor da Serra',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  29.90, 34.38, 31, 'TST-020201', TRUE
FROM stores s
JOIN categories c ON c.slug='alimentacao'
WHERE s.slug='sabor-da-serra';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Marmita Executiva - Sabor da Serra',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  24.90, 28.63, 32, 'TST-020202', TRUE
FROM stores s
JOIN categories c ON c.slug='alimentacao'
WHERE s.slug='sabor-da-serra';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Cantina do Centro','lojista06@teste.minhacidadeaqui.com.br','(11) 99200-0006',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Cantina do Centro', 'cantina-do-centro',
  'Empresa fictícia de teste da categoria Alimentação.',
  '(11) 99200-0006', 'contato@cantina-do-centro.teste',
  '13210006', 'Avenida Comercial 6', '206',
  'Região 6', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='alimentacao'
WHERE u.email='lojista06@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Marmita Executiva - Cantina do Centro',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  24.90, 28.63, 36, 'TST-020301', TRUE
FROM stores s
JOIN categories c ON c.slug='alimentacao'
WHERE s.slug='cantina-do-centro';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Pizza Margherita - Cantina do Centro',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  38.90, 44.73, 37, 'TST-020302', TRUE
FROM stores s
JOIN categories c ON c.slug='alimentacao'
WHERE s.slug='cantina-do-centro';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Casa & Estilo','lojista07@teste.minhacidadeaqui.com.br','(11) 99200-0007',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Casa & Estilo', 'casa-estilo',
  'Empresa fictícia de teste da categoria Casa e Decoração.',
  '(11) 99200-0007', 'contato@casa-estilo.teste',
  '13210007', 'Avenida Comercial 7', '207',
  'Região 1', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='casa-decoracao'
WHERE u.email='lojista07@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Luminária de Mesa - Casa & Estilo',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  89.90, 103.39, 26, 'TST-030101', TRUE
FROM stores s
JOIN categories c ON c.slug='casa-decoracao'
WHERE s.slug='casa-estilo';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Organizadores - Casa & Estilo',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  49.90, 57.38, 27, 'TST-030102', TRUE
FROM stores s
JOIN categories c ON c.slug='casa-decoracao'
WHERE s.slug='casa-estilo';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Lar em Cores','lojista08@teste.minhacidadeaqui.com.br','(11) 99200-0008',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Lar em Cores', 'lar-em-cores',
  'Empresa fictícia de teste da categoria Casa e Decoração.',
  '(11) 99200-0008', 'contato@lar-em-cores.teste',
  '13210008', 'Avenida Comercial 8', '208',
  'Região 2', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='casa-decoracao'
WHERE u.email='lojista08@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Organizadores - Lar em Cores',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  49.90, 57.38, 31, 'TST-030201', TRUE
FROM stores s
JOIN categories c ON c.slug='casa-decoracao'
WHERE s.slug='lar-em-cores';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Almofada Decorativa - Lar em Cores',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  39.90, 45.88, 32, 'TST-030202', TRUE
FROM stores s
JOIN categories c ON c.slug='casa-decoracao'
WHERE s.slug='lar-em-cores';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Decor Jundiaí','lojista09@teste.minhacidadeaqui.com.br','(11) 99200-0009',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Decor Jundiaí', 'decor-jundiai',
  'Empresa fictícia de teste da categoria Casa e Decoração.',
  '(11) 99200-0009', 'contato@decor-jundiai.teste',
  '13210009', 'Avenida Comercial 9', '209',
  'Região 3', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='casa-decoracao'
WHERE u.email='lojista09@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Almofada Decorativa - Decor Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  39.90, 45.88, 36, 'TST-030301', TRUE
FROM stores s
JOIN categories c ON c.slug='casa-decoracao'
WHERE s.slug='decor-jundiai';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Luminária de Mesa - Decor Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  89.90, 103.39, 37, 'TST-030302', TRUE
FROM stores s
JOIN categories c ON c.slug='casa-decoracao'
WHERE s.slug='decor-jundiai';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Vida & Beleza','lojista10@teste.minhacidadeaqui.com.br','(11) 99200-0010',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Vida & Beleza', 'vida-beleza',
  'Empresa fictícia de teste da categoria Beleza e Saúde.',
  '(11) 99200-0010', 'contato@vida-beleza.teste',
  '13210010', 'Avenida Comercial 10', '210',
  'Região 4', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='beleza-saude'
WHERE u.email='lojista10@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Cuidados Pessoais - Vida & Beleza',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  54.90, 63.13, 26, 'TST-040101', TRUE
FROM stores s
JOIN categories c ON c.slug='beleza-saude'
WHERE s.slug='vida-beleza';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Sessão de Bem-estar - Vida & Beleza',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  95.00, 109.25, 27, 'TST-040102', TRUE
FROM stores s
JOIN categories c ON c.slug='beleza-saude'
WHERE s.slug='vida-beleza';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Espaço Saúde','lojista11@teste.minhacidadeaqui.com.br','(11) 99200-0011',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Espaço Saúde', 'espaco-saude',
  'Empresa fictícia de teste da categoria Beleza e Saúde.',
  '(11) 99200-0011', 'contato@espaco-saude.teste',
  '13210011', 'Avenida Comercial 11', '211',
  'Região 5', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='beleza-saude'
WHERE u.email='lojista11@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Sessão de Bem-estar - Espaço Saúde',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  95.00, 109.25, 31, 'TST-040201', TRUE
FROM stores s
JOIN categories c ON c.slug='beleza-saude'
WHERE s.slug='espaco-saude';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Shampoo Premium - Espaço Saúde',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  32.90, 37.83, 32, 'TST-040202', TRUE
FROM stores s
JOIN categories c ON c.slug='beleza-saude'
WHERE s.slug='espaco-saude';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Studio Essenza','lojista12@teste.minhacidadeaqui.com.br','(11) 99200-0012',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Studio Essenza', 'studio-essenza',
  'Empresa fictícia de teste da categoria Beleza e Saúde.',
  '(11) 99200-0012', 'contato@studio-essenza.teste',
  '13210012', 'Avenida Comercial 12', '212',
  'Região 6', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='beleza-saude'
WHERE u.email='lojista12@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Shampoo Premium - Studio Essenza',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  32.90, 37.83, 36, 'TST-040301', TRUE
FROM stores s
JOIN categories c ON c.slug='beleza-saude'
WHERE s.slug='studio-essenza';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Cuidados Pessoais - Studio Essenza',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  54.90, 63.13, 37, 'TST-040302', TRUE
FROM stores s
JOIN categories c ON c.slug='beleza-saude'
WHERE s.slug='studio-essenza';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Moda Urbana','lojista13@teste.minhacidadeaqui.com.br','(11) 99200-0013',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Moda Urbana', 'moda-urbana',
  'Empresa fictícia de teste da categoria Moda.',
  '(11) 99200-0013', 'contato@moda-urbana.teste',
  '13210013', 'Avenida Comercial 13', '213',
  'Região 1', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='moda'
WHERE u.email='lojista13@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Camiseta Casual - Moda Urbana',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  69.90, 80.39, 26, 'TST-050101', TRUE
FROM stores s
JOIN categories c ON c.slug='moda'
WHERE s.slug='moda-urbana';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Calça Jeans - Moda Urbana',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  129.90, 149.38, 27, 'TST-050102', TRUE
FROM stores s
JOIN categories c ON c.slug='moda'
WHERE s.slug='moda-urbana';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Estilo da Cidade','lojista14@teste.minhacidadeaqui.com.br','(11) 99200-0014',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Estilo da Cidade', 'estilo-da-cidade',
  'Empresa fictícia de teste da categoria Moda.',
  '(11) 99200-0014', 'contato@estilo-da-cidade.teste',
  '13210014', 'Avenida Comercial 14', '214',
  'Região 2', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='moda'
WHERE u.email='lojista14@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Calça Jeans - Estilo da Cidade',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  129.90, 149.38, 31, 'TST-050201', TRUE
FROM stores s
JOIN categories c ON c.slug='moda'
WHERE s.slug='estilo-da-cidade';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Bolsa Urbana - Estilo da Cidade',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  149.90, 172.38, 32, 'TST-050202', TRUE
FROM stores s
JOIN categories c ON c.slug='moda'
WHERE s.slug='estilo-da-cidade';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Vitrine Jundiaí','lojista15@teste.minhacidadeaqui.com.br','(11) 99200-0015',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Vitrine Jundiaí', 'vitrine-jundiai',
  'Empresa fictícia de teste da categoria Moda.',
  '(11) 99200-0015', 'contato@vitrine-jundiai.teste',
  '13210015', 'Avenida Comercial 15', '215',
  'Região 3', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='moda'
WHERE u.email='lojista15@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Bolsa Urbana - Vitrine Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  149.90, 172.38, 36, 'TST-050301', TRUE
FROM stores s
JOIN categories c ON c.slug='moda'
WHERE s.slug='vitrine-jundiai';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Camiseta Casual - Vitrine Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  69.90, 80.39, 37, 'TST-050302', TRUE
FROM stores s
JOIN categories c ON c.slug='moda'
WHERE s.slug='vitrine-jundiai';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Tech Local','lojista16@teste.minhacidadeaqui.com.br','(11) 99200-0016',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Tech Local', 'tech-local',
  'Empresa fictícia de teste da categoria Eletrônicos.',
  '(11) 99200-0016', 'contato@tech-local.teste',
  '13210016', 'Avenida Comercial 16', '216',
  'Região 4', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='eletronicos'
WHERE u.email='lojista16@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Fone Bluetooth - Tech Local',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  99.90, 114.88, 26, 'TST-060101', TRUE
FROM stores s
JOIN categories c ON c.slug='eletronicos'
WHERE s.slug='tech-local';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Carregador USB-C - Tech Local',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  59.90, 68.88, 27, 'TST-060102', TRUE
FROM stores s
JOIN categories c ON c.slug='eletronicos'
WHERE s.slug='tech-local';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Conecta Eletrônicos','lojista17@teste.minhacidadeaqui.com.br','(11) 99200-0017',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Conecta Eletrônicos', 'conecta-eletronicos',
  'Empresa fictícia de teste da categoria Eletrônicos.',
  '(11) 99200-0017', 'contato@conecta-eletronicos.teste',
  '13210017', 'Avenida Comercial 17', '217',
  'Região 5', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='eletronicos'
WHERE u.email='lojista17@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Carregador USB-C - Conecta Eletrônicos',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  59.90, 68.88, 31, 'TST-060201', TRUE
FROM stores s
JOIN categories c ON c.slug='eletronicos'
WHERE s.slug='conecta-eletronicos';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Mouse Sem Fio - Conecta Eletrônicos',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  79.90, 91.89, 32, 'TST-060202', TRUE
FROM stores s
JOIN categories c ON c.slug='eletronicos'
WHERE s.slug='conecta-eletronicos';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Smart City Tech','lojista18@teste.minhacidadeaqui.com.br','(11) 99200-0018',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Smart City Tech', 'smart-city-tech',
  'Empresa fictícia de teste da categoria Eletrônicos.',
  '(11) 99200-0018', 'contato@smart-city-tech.teste',
  '13210018', 'Avenida Comercial 18', '218',
  'Região 6', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='eletronicos'
WHERE u.email='lojista18@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Mouse Sem Fio - Smart City Tech',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  79.90, 91.89, 36, 'TST-060301', TRUE
FROM stores s
JOIN categories c ON c.slug='eletronicos'
WHERE s.slug='smart-city-tech';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Fone Bluetooth - Smart City Tech',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  99.90, 114.88, 37, 'TST-060302', TRUE
FROM stores s
JOIN categories c ON c.slug='eletronicos'
WHERE s.slug='smart-city-tech';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Pet Amigo','lojista19@teste.minhacidadeaqui.com.br','(11) 99200-0019',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Pet Amigo', 'pet-amigo',
  'Empresa fictícia de teste da categoria Pet.',
  '(11) 99200-0019', 'contato@pet-amigo.teste',
  '13210019', 'Avenida Comercial 19', '219',
  'Região 1', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='pet'
WHERE u.email='lojista19@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Ração Premium 3kg - Pet Amigo',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  84.90, 97.64, 26, 'TST-070101', TRUE
FROM stores s
JOIN categories c ON c.slug='pet'
WHERE s.slug='pet-amigo';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Pet Higiene - Pet Amigo',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  39.90, 45.88, 27, 'TST-070102', TRUE
FROM stores s
JOIN categories c ON c.slug='pet'
WHERE s.slug='pet-amigo';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Mundo Pet Local','lojista20@teste.minhacidadeaqui.com.br','(11) 99200-0020',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Mundo Pet Local', 'mundo-pet-local',
  'Empresa fictícia de teste da categoria Pet.',
  '(11) 99200-0020', 'contato@mundo-pet-local.teste',
  '13210020', 'Avenida Comercial 20', '220',
  'Região 2', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='pet'
WHERE u.email='lojista20@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Pet Higiene - Mundo Pet Local',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  39.90, 45.88, 31, 'TST-070201', TRUE
FROM stores s
JOIN categories c ON c.slug='pet'
WHERE s.slug='mundo-pet-local';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Brinquedo Interativo - Mundo Pet Local',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  29.90, 34.38, 32, 'TST-070202', TRUE
FROM stores s
JOIN categories c ON c.slug='pet'
WHERE s.slug='mundo-pet-local';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Pet Vila','lojista21@teste.minhacidadeaqui.com.br','(11) 99200-0021',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Pet Vila', 'pet-vila',
  'Empresa fictícia de teste da categoria Pet.',
  '(11) 99200-0021', 'contato@pet-vila.teste',
  '13210021', 'Avenida Comercial 21', '221',
  'Região 3', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='pet'
WHERE u.email='lojista21@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Brinquedo Interativo - Pet Vila',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  29.90, 34.38, 36, 'TST-070301', TRUE
FROM stores s
JOIN categories c ON c.slug='pet'
WHERE s.slug='pet-vila';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Ração Premium 3kg - Pet Vila',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  84.90, 97.64, 37, 'TST-070302', TRUE
FROM stores s
JOIN categories c ON c.slug='pet'
WHERE s.slug='pet-vila';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Fix Home Serviços','lojista22@teste.minhacidadeaqui.com.br','(11) 99200-0022',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Fix Home Serviços', 'fix-home-servicos',
  'Empresa fictícia de teste da categoria Serviços.',
  '(11) 99200-0022', 'contato@fix-home-servicos.teste',
  '13210022', 'Avenida Comercial 22', '222',
  'Região 4', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='servicos'
WHERE u.email='lojista22@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Visita Técnica - Fix Home Serviços',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  120.00, 138.00, 26, 'TST-080101', TRUE
FROM stores s
JOIN categories c ON c.slug='servicos'
WHERE s.slug='fix-home-servicos';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Instalação Residencial - Fix Home Serviços',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  180.00, 207.00, 27, 'TST-080102', TRUE
FROM stores s
JOIN categories c ON c.slug='servicos'
WHERE s.slug='fix-home-servicos';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Elétrica da Cidade','lojista23@teste.minhacidadeaqui.com.br','(11) 99200-0023',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Elétrica da Cidade', 'eletrica-da-cidade',
  'Empresa fictícia de teste da categoria Serviços.',
  '(11) 99200-0023', 'contato@eletrica-da-cidade.teste',
  '13210023', 'Avenida Comercial 23', '223',
  'Região 5', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='servicos'
WHERE u.email='lojista23@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Instalação Residencial - Elétrica da Cidade',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  180.00, 207.00, 31, 'TST-080201', TRUE
FROM stores s
JOIN categories c ON c.slug='servicos'
WHERE s.slug='eletrica-da-cidade';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Manutenção Expressa - Elétrica da Cidade',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  95.00, 109.25, 32, 'TST-080202', TRUE
FROM stores s
JOIN categories c ON c.slug='servicos'
WHERE s.slug='eletrica-da-cidade';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Chave & Cia Serviços','lojista24@teste.minhacidadeaqui.com.br','(11) 99200-0024',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Chave & Cia Serviços', 'chave-cia-servicos',
  'Empresa fictícia de teste da categoria Serviços.',
  '(11) 99200-0024', 'contato@chave-cia-servicos.teste',
  '13210024', 'Avenida Comercial 24', '224',
  'Região 6', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='servicos'
WHERE u.email='lojista24@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Manutenção Expressa - Chave & Cia Serviços',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  95.00, 109.25, 36, 'TST-080301', TRUE
FROM stores s
JOIN categories c ON c.slug='servicos'
WHERE s.slug='chave-cia-servicos';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Visita Técnica - Chave & Cia Serviços',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  120.00, 138.00, 37, 'TST-080302', TRUE
FROM stores s
JOIN categories c ON c.slug='servicos'
WHERE s.slug='chave-cia-servicos';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Arena Sports','lojista25@teste.minhacidadeaqui.com.br','(11) 99200-0025',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Arena Sports', 'arena-sports',
  'Empresa fictícia de teste da categoria Esportes.',
  '(11) 99200-0025', 'contato@arena-sports.teste',
  '13210025', 'Avenida Comercial 25', '225',
  'Região 1', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='esportes'
WHERE u.email='lojista25@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Bola Oficial - Arena Sports',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  89.90, 103.39, 26, 'TST-090101', TRUE
FROM stores s
JOIN categories c ON c.slug='esportes'
WHERE s.slug='arena-sports';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Camiseta Esportiva - Arena Sports',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  79.90, 91.89, 27, 'TST-090102', TRUE
FROM stores s
JOIN categories c ON c.slug='esportes'
WHERE s.slug='arena-sports';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Ação Fitness Store','lojista26@teste.minhacidadeaqui.com.br','(11) 99200-0026',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Ação Fitness Store', 'acao-fitness-store',
  'Empresa fictícia de teste da categoria Esportes.',
  '(11) 99200-0026', 'contato@acao-fitness-store.teste',
  '13210026', 'Avenida Comercial 26', '226',
  'Região 2', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='esportes'
WHERE u.email='lojista26@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Camiseta Esportiva - Ação Fitness Store',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  79.90, 91.89, 31, 'TST-090201', TRUE
FROM stores s
JOIN categories c ON c.slug='esportes'
WHERE s.slug='acao-fitness-store';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Treino - Ação Fitness Store',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  119.90, 137.88, 32, 'TST-090202', TRUE
FROM stores s
JOIN categories c ON c.slug='esportes'
WHERE s.slug='acao-fitness-store';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Esporte Jundiaí','lojista27@teste.minhacidadeaqui.com.br','(11) 99200-0027',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Esporte Jundiaí', 'esporte-jundiai',
  'Empresa fictícia de teste da categoria Esportes.',
  '(11) 99200-0027', 'contato@esporte-jundiai.teste',
  '13210027', 'Avenida Comercial 27', '227',
  'Região 3', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='esportes'
WHERE u.email='lojista27@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Treino - Esporte Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  119.90, 137.88, 36, 'TST-090301', TRUE
FROM stores s
JOIN categories c ON c.slug='esportes'
WHERE s.slug='esporte-jundiai';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Bola Oficial - Esporte Jundiaí',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  89.90, 103.39, 37, 'TST-090302', TRUE
FROM stores s
JOIN categories c ON c.slug='esportes'
WHERE s.slug='esporte-jundiai';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Auto Prime Local','lojista28@teste.minhacidadeaqui.com.br','(11) 99200-0028',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Auto Prime Local', 'auto-prime-local',
  'Empresa fictícia de teste da categoria Auto e Moto.',
  '(11) 99200-0028', 'contato@auto-prime-local.teste',
  '13210028', 'Avenida Comercial 28', '228',
  'Região 4', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='auto-moto'
WHERE u.email='lojista28@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Limpeza Automotiva - Auto Prime Local',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  69.90, 80.39, 26, 'TST-100101', TRUE
FROM stores s
JOIN categories c ON c.slug='auto-moto'
WHERE s.slug='auto-prime-local';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Palheta Limpador - Auto Prime Local',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  49.90, 57.38, 27, 'TST-100102', TRUE
FROM stores s
JOIN categories c ON c.slug='auto-moto'
WHERE s.slug='auto-prime-local';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Moto & Cia','lojista29@teste.minhacidadeaqui.com.br','(11) 99200-0029',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Moto & Cia', 'moto-cia',
  'Empresa fictícia de teste da categoria Auto e Moto.',
  '(11) 99200-0029', 'contato@moto-cia.teste',
  '13210029', 'Avenida Comercial 29', '229',
  'Região 5', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='auto-moto'
WHERE u.email='lojista29@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Palheta Limpador - Moto & Cia',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  49.90, 57.38, 31, 'TST-100201', TRUE
FROM stores s
JOIN categories c ON c.slug='auto-moto'
WHERE s.slug='moto-cia';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Troca de Óleo - Moto & Cia',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  169.90, 195.38, 32, 'TST-100202', TRUE
FROM stores s
JOIN categories c ON c.slug='auto-moto'
WHERE s.slug='moto-cia';


INSERT INTO users (name,email,phone,password_hash,role)
VALUES ('Responsável Jundiaí Auto Peças','lojista30@teste.minhacidadeaqui.com.br','(11) 99200-0030',crypt('Teste123!', gen_salt('bf',10)),'merchant')
ON CONFLICT (email) DO NOTHING;

INSERT INTO stores (
  owner_user_id, primary_category_id, name, slug, description, phone, email,
  cep, street, number, district, city, state, open_time, close_time, is_open, is_active
)
SELECT
  u.id, c.id, 'Jundiaí Auto Peças', 'jundiai-auto-pecas',
  'Empresa fictícia de teste da categoria Auto e Moto.',
  '(11) 99200-0030', 'contato@jundiai-auto-pecas.teste',
  '13210030', 'Avenida Comercial 30', '230',
  'Região 6', 'Jundiaí','SP','08:00','18:00',TRUE,TRUE
FROM users u
JOIN categories c ON c.slug='auto-moto'
WHERE u.email='lojista30@teste.minhacidadeaqui.com.br'
ON CONFLICT (slug) DO NOTHING;


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Troca de Óleo - Jundiaí Auto Peças',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  169.90, 195.38, 36, 'TST-100301', TRUE
FROM stores s
JOIN categories c ON c.slug='auto-moto'
WHERE s.slug='jundiai-auto-pecas';


INSERT INTO products (
  store_id, category_id, name, description, price, compare_at_price, stock, sku, is_active
)
SELECT
  s.id, c.id, 'Kit Limpeza Automotiva - Jundiaí Auto Peças',
  'Produto fictício para testes integrados do Minha Cidade Aqui.',
  69.90, 80.39, 37, 'TST-100302', TRUE
FROM stores s
JOIN categories c ON c.slug='auto-moto'
WHERE s.slug='jundiai-auto-pecas';


WITH chosen_product AS (
  SELECT p.id, p.name, p.price, p.store_id
  FROM products p
  JOIN stores s ON s.id=p.store_id
  WHERE s.slug='mercado-vila-nova'
  ORDER BY p.created_at
  LIMIT 1
),
new_order AS (
  INSERT INTO orders (
    customer_user_id,store_id,status,fulfillment_type,delivery_address,
    payment_method,payment_status,subtotal,delivery_fee,total,notes
  )
  SELECT
    u.id, cp.store_id,'pending','delivery',
    'Rua Teste 1, 101 - Jundiaí/SP',
    'pix',
    CASE WHEN 'pending'='pending' THEN 'pending' ELSE 'paid' END,
    cp.price, 8.90, cp.price + 8.90,
    'Pedido fictício para teste do fluxo.'
  FROM users u CROSS JOIN chosen_product cp
  WHERE u.email='ana.clara@teste.minhacidadeaqui.com.br'
  RETURNING id
)
INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity)
SELECT no.id,cp.id,cp.name,cp.price,1
FROM new_order no CROSS JOIN chosen_product cp;


WITH chosen_product AS (
  SELECT p.id, p.name, p.price, p.store_id
  FROM products p
  JOIN stores s ON s.id=p.store_id
  WHERE s.slug='pizzaria-bela-praca'
  ORDER BY p.created_at
  LIMIT 1
),
new_order AS (
  INSERT INTO orders (
    customer_user_id,store_id,status,fulfillment_type,delivery_address,
    payment_method,payment_status,subtotal,delivery_fee,total,notes
  )
  SELECT
    u.id, cp.store_id,'confirmed','delivery',
    'Rua Teste 2, 102 - Jundiaí/SP',
    'pix',
    CASE WHEN 'confirmed'='pending' THEN 'pending' ELSE 'paid' END,
    cp.price, 8.90, cp.price + 8.90,
    'Pedido fictício para teste do fluxo.'
  FROM users u CROSS JOIN chosen_product cp
  WHERE u.email='bruno.santos@teste.minhacidadeaqui.com.br'
  RETURNING id
)
INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity)
SELECT no.id,cp.id,cp.name,cp.price,1
FROM new_order no CROSS JOIN chosen_product cp;


WITH chosen_product AS (
  SELECT p.id, p.name, p.price, p.store_id
  FROM products p
  JOIN stores s ON s.id=p.store_id
  WHERE s.slug='casa-estilo'
  ORDER BY p.created_at
  LIMIT 1
),
new_order AS (
  INSERT INTO orders (
    customer_user_id,store_id,status,fulfillment_type,delivery_address,
    payment_method,payment_status,subtotal,delivery_fee,total,notes
  )
  SELECT
    u.id, cp.store_id,'preparing','delivery',
    'Rua Teste 3, 103 - Jundiaí/SP',
    'pix',
    CASE WHEN 'preparing'='pending' THEN 'pending' ELSE 'paid' END,
    cp.price, 8.90, cp.price + 8.90,
    'Pedido fictício para teste do fluxo.'
  FROM users u CROSS JOIN chosen_product cp
  WHERE u.email='carla.oliveira@teste.minhacidadeaqui.com.br'
  RETURNING id
)
INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity)
SELECT no.id,cp.id,cp.name,cp.price,1
FROM new_order no CROSS JOIN chosen_product cp;


WITH chosen_product AS (
  SELECT p.id, p.name, p.price, p.store_id
  FROM products p
  JOIN stores s ON s.id=p.store_id
  WHERE s.slug='vida-beleza'
  ORDER BY p.created_at
  LIMIT 1
),
new_order AS (
  INSERT INTO orders (
    customer_user_id,store_id,status,fulfillment_type,delivery_address,
    payment_method,payment_status,subtotal,delivery_fee,total,notes
  )
  SELECT
    u.id, cp.store_id,'ready','delivery',
    'Rua Teste 4, 104 - Jundiaí/SP',
    'pix',
    CASE WHEN 'ready'='pending' THEN 'pending' ELSE 'paid' END,
    cp.price, 8.90, cp.price + 8.90,
    'Pedido fictício para teste do fluxo.'
  FROM users u CROSS JOIN chosen_product cp
  WHERE u.email='daniel.costa@teste.minhacidadeaqui.com.br'
  RETURNING id
)
INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity)
SELECT no.id,cp.id,cp.name,cp.price,1
FROM new_order no CROSS JOIN chosen_product cp;


WITH chosen_product AS (
  SELECT p.id, p.name, p.price, p.store_id
  FROM products p
  JOIN stores s ON s.id=p.store_id
  WHERE s.slug='moda-urbana'
  ORDER BY p.created_at
  LIMIT 1
),
new_order AS (
  INSERT INTO orders (
    customer_user_id,store_id,status,fulfillment_type,delivery_address,
    payment_method,payment_status,subtotal,delivery_fee,total,notes
  )
  SELECT
    u.id, cp.store_id,'awaiting_driver','delivery',
    'Rua Teste 5, 105 - Jundiaí/SP',
    'pix',
    CASE WHEN 'awaiting_driver'='pending' THEN 'pending' ELSE 'paid' END,
    cp.price, 8.90, cp.price + 8.90,
    'Pedido fictício para teste do fluxo.'
  FROM users u CROSS JOIN chosen_product cp
  WHERE u.email='eduarda.lima@teste.minhacidadeaqui.com.br'
  RETURNING id
)
INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity)
SELECT no.id,cp.id,cp.name,cp.price,1
FROM new_order no CROSS JOIN chosen_product cp;


WITH chosen_product AS (
  SELECT p.id, p.name, p.price, p.store_id
  FROM products p
  JOIN stores s ON s.id=p.store_id
  WHERE s.slug='tech-local'
  ORDER BY p.created_at
  LIMIT 1
),
new_order AS (
  INSERT INTO orders (
    customer_user_id,store_id,status,fulfillment_type,delivery_address,
    payment_method,payment_status,subtotal,delivery_fee,total,notes
  )
  SELECT
    u.id, cp.store_id,'completed','delivery',
    'Rua Teste 6, 106 - Jundiaí/SP',
    'pix',
    CASE WHEN 'completed'='pending' THEN 'pending' ELSE 'paid' END,
    cp.price, 8.90, cp.price + 8.90,
    'Pedido fictício para teste do fluxo.'
  FROM users u CROSS JOIN chosen_product cp
  WHERE u.email='felipe.martins@teste.minhacidadeaqui.com.br'
  RETURNING id
)
INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity)
SELECT no.id,cp.id,cp.name,cp.price,1
FROM new_order no CROSS JOIN chosen_product cp;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 0 LIMIT 1
) p
WHERE u.email='ana.clara@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 1 LIMIT 1
) p
WHERE u.email='bruno.santos@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 2 LIMIT 1
) p
WHERE u.email='carla.oliveira@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 3 LIMIT 1
) p
WHERE u.email='daniel.costa@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 4 LIMIT 1
) p
WHERE u.email='eduarda.lima@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 5 LIMIT 1
) p
WHERE u.email='felipe.martins@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 6 LIMIT 1
) p
WHERE u.email='gabriela.rocha@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 7 LIMIT 1
) p
WHERE u.email='henrique.alves@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 8 LIMIT 1
) p
WHERE u.email='isabela.mendes@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


INSERT INTO favorites (user_id,product_id)
SELECT u.id,p.id
FROM users u
CROSS JOIN LATERAL (
  SELECT id FROM products ORDER BY created_at OFFSET 9 LIMIT 1
) p
WHERE u.email='joao.souza@teste.minhacidadeaqui.com.br'
ON CONFLICT DO NOTHING;


COMMIT;

SELECT role, COUNT(*) FROM users GROUP BY role ORDER BY role;
SELECT c.name AS categoria, COUNT(s.id) AS lojas
FROM categories c LEFT JOIN stores s ON s.primary_category_id=c.id
GROUP BY c.name ORDER BY c.name;
SELECT COUNT(*) AS produtos FROM products;
SELECT COUNT(*) AS pedidos FROM orders;
