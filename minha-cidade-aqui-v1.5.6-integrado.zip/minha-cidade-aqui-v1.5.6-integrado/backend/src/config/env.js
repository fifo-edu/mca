import dotenv from "dotenv";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
export const envPath = path.resolve(__dirname, "../../.env");

const result = dotenv.config({ path: envPath, override: true });
if (result.error && result.error.code !== "ENOENT") {
  console.error("Erro ao carregar .env:", result.error.message);
}

export const envStatus = {
  envFileFound: fs.existsSync(envPath),
  dbPasswordConfigured: typeof process.env.DB_PASSWORD === "string" && process.env.DB_PASSWORD.length > 0,
  jwtSecretConfigured: typeof process.env.JWT_SECRET === "string" && process.env.JWT_SECRET.trim().length > 0
};
