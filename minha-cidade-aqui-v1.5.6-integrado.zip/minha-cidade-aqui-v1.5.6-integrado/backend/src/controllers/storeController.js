import { pool } from "../config/db.js";

export async function listStores(req, res) {
  try {
    const result = await pool.query(
      `SELECT id, name, slug, description, phone, email,
              cep, street, number, complement, district,
              city, state, latitude, longitude,
              is_open, open_time, close_time
       FROM stores
       WHERE is_active = TRUE
       ORDER BY name`
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar lojas." });
  }
}

export async function createStore(req, res) {
  try {
    const {
      name, slug, description, phone, email,
      cep, street, number, complement, district,
      city, state = "SP", latitude, longitude,
      open_time, close_time
    } = req.body;

    if (!name || !slug || !city) {
      return res.status(400).json({ error: "Nome, slug e cidade são obrigatórios." });
    }

    const result = await pool.query(
      `INSERT INTO stores
       (owner_user_id, name, slug, description, phone, email,
        cep, street, number, complement, district, city, state,
        latitude, longitude, open_time, close_time)
       VALUES
       ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
       RETURNING *`,
      [
        req.user.id, name, slug, description || null, phone || null, email || null,
        cep || null, street || null, number || null, complement || null, district || null,
        city, state, latitude || null, longitude || null, open_time || null, close_time || null
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({ error: "Slug já utilizado." });
    }
    console.error(error);
    res.status(500).json({ error: "Erro ao criar loja." });
  }
}

export async function getStore(req, res) {
  try {
    const result = await pool.query(
      `SELECT id, name, slug, description, phone, email,
              cep, street, number, complement, district,
              city, state, latitude, longitude,
              is_open, open_time, close_time
       FROM stores
       WHERE id = $1 AND is_active = TRUE`,
      [req.params.id]
    );

    if (!result.rowCount) return res.status(404).json({ error: "Loja não encontrada." });

    const products = await pool.query(
      `SELECT p.id, p.name, p.description, p.price, p.compare_at_price,
              p.stock, p.sku, p.image_url,
              c.name AS category
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.store_id = $1 AND p.is_active = TRUE
       ORDER BY p.name`,
      [req.params.id]
    );

    res.json({ ...result.rows[0], products: products.rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar loja." });
  }
}

export async function myStores(req, res) {
  try {
    const result = await pool.query(
      `SELECT id, name, slug, description, phone, email,
              cep, street, number, complement, district,
              city, state, latitude, longitude,
              is_open, open_time, close_time, is_active, created_at
       FROM stores
       WHERE owner_user_id = $1
       ORDER BY created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar lojas do lojista." });
  }
}

export async function updateStore(req, res) {
  try {
    const {
      name, description, phone, email,
      cep, street, number, complement, district,
      city, state, latitude, longitude,
      open_time, close_time, is_open, is_active
    } = req.body;

    const result = await pool.query(
      `UPDATE stores
       SET name = COALESCE($1, name),
           description = COALESCE($2, description),
           phone = COALESCE($3, phone),
           email = COALESCE($4, email),
           cep = COALESCE($5, cep),
           street = COALESCE($6, street),
           number = COALESCE($7, number),
           complement = COALESCE($8, complement),
           district = COALESCE($9, district),
           city = COALESCE($10, city),
           state = COALESCE($11, state),
           latitude = COALESCE($12, latitude),
           longitude = COALESCE($13, longitude),
           open_time = COALESCE($14, open_time),
           close_time = COALESCE($15, close_time),
           is_open = COALESCE($16, is_open),
           is_active = COALESCE($17, is_active)
       WHERE id = $18 AND owner_user_id = $19
       RETURNING *`,
      [
        name ?? null, description ?? null, phone ?? null, email ?? null,
        cep ?? null, street ?? null, number ?? null, complement ?? null, district ?? null,
        city ?? null, state ?? null, latitude ?? null, longitude ?? null,
        open_time ?? null, close_time ?? null, is_open ?? null, is_active ?? null,
        req.params.id, req.user.id
      ]
    );

    if (!result.rowCount) return res.status(404).json({ error: "Loja não encontrada." });
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao atualizar loja." });
  }
}
