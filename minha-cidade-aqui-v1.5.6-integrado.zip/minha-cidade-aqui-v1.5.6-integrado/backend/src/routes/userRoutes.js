import { Router } from "express";
import { updateMe } from "../controllers/userController.js";
import { authRequired } from "../middlewares/auth.js";

const router = Router();

router.patch("/me", authRequired, updateMe);

export default router;
