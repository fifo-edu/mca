import { pool } from "../config/db.js";

async function resolveCategoryId(categoryName, client = pool) {
  if (!categoryName) return null;

  const normalized = String(categoryName).trim();
  if (!normalized) return null;

  let result = await client.query(
    `SELECT id FROM categories
     WHERE LOWER(name) = LOWER($1) OR LOWER(slug) = LOWER($1)
     LIMIT 1`,
    [normalized]
  );

  if (result.rowCount) return result.rows[0].id;

  const slug = normalized
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

  result = await client.query(
    `INSERT INTO categories (name, slug)
     VALUES ($1, $2)
     ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name
     RETURNING id`,
    [normalized, slug]
  );

  return result.rows[0].id;
}

export async function listProducts(req, res) {
  try {
    const { q, category, store_id } = req.query;
    const values = [];
    const where = ["p.is_active = TRUE", "s.is_active = TRUE"];

    if (q) {
      values.push(`%${q}%`);
      where.push(`(
        p.name ILIKE $${values.length}
        OR COALESCE(p.description,'') ILIKE $${values.length}
        OR s.name ILIKE $${values.length}
      )`);
    }

    if (category) {
      values.push(category);
      where.push(`(
        LOWER(c.name) = LOWER($${values.length})
        OR LOWER(c.slug) = LOWER($${values.length})
      )`);
    }

    if (store_id) {
      values.push(store_id);
      where.push(`p.store_id = $${values.length}`);
    }

    const result = await pool.query(
      `SELECT
         p.id,
         p.name,
         p.description,
         p.price,
         p.compare_at_price,
         p.stock,
         p.sku,
         p.image_url,
         p.is_active,
         c.id AS category_id,
         c.name AS category,
         c.slug AS category_slug,
         s.id AS store_id,
         s.name AS store_name
       FROM products p
       JOIN stores s ON s.id = p.store_id
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE ${where.join(" AND ")}
       ORDER BY p.created_at DESC`,
      values
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar produtos." });
  }
}

export async function createProduct(req, res) {
  const {
    store_id, name, description, price, stock = 0,
    category, image_url, compare_at_price, sku
  } = req.body;

  if (!store_id || !name || price === undefined || price === null) {
    return res.status(400).json({ error: "Loja, nome e preço são obrigatórios." });
  }

  try {
    const store = await pool.query(
      "SELECT id FROM stores WHERE id = $1 AND owner_user_id = $2 AND is_active = TRUE",
      [store_id, req.user.id]
    );

    if (!store.rowCount) {
      return res.status(403).json({ error: "Esta loja não pertence ao usuário autenticado." });
    }

    const categoryId = await resolveCategoryId(category);

    const result = await pool.query(
      `INSERT INTO products
       (store_id, category_id, name, description, price, compare_at_price, stock, sku, image_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING *`,
      [
        store_id,
        categoryId,
        name,
        description || null,
        Number(price),
        compare_at_price ? Number(compare_at_price) : null,
        Number(stock || 0),
        sku || null,
        image_url || null
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao cadastrar produto." });
  }
}

export async function myProducts(req, res) {
  try {
    const result = await pool.query(
      `SELECT
         p.id, p.name, p.description, p.price, p.compare_at_price,
         p.stock, p.sku, p.image_url, p.is_active, p.created_at,
         c.id AS category_id, c.name AS category,
         s.id AS store_id, s.name AS store_name
       FROM products p
       JOIN stores s ON s.id = p.store_id
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE s.owner_user_id = $1
       ORDER BY p.created_at DESC`,
      [req.user.id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar produtos do lojista." });
  }
}

export async function updateProduct(req, res) {
  const client = await pool.connect();

  try {
    const {
      name, description, price, compare_at_price, stock,
      category, image_url, sku, is_active
    } = req.body;

    await client.query("BEGIN");

    const owned = await client.query(
      `SELECT p.id, p.category_id
       FROM products p
       JOIN stores s ON s.id = p.store_id
       WHERE p.id = $1 AND s.owner_user_id = $2
       FOR UPDATE`,
      [req.params.id, req.user.id]
    );

    if (!owned.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Produto não encontrado." });
    }

    let categoryId = owned.rows[0].category_id;
    if (category !== undefined) {
      categoryId = await resolveCategoryId(category, client);
    }

    const result = await client.query(
      `UPDATE products
       SET name = COALESCE($1, name),
           description = COALESCE($2, description),
           price = COALESCE($3, price),
           compare_at_price = COALESCE($4, compare_at_price),
           stock = COALESCE($5, stock),
           category_id = $6,
           image_url = COALESCE($7, image_url),
           sku = COALESCE($8, sku),
           is_active = COALESCE($9, is_active)
       WHERE id = $10
       RETURNING *`,
      [
        name ?? null,
        description ?? null,
        price ?? null,
        compare_at_price ?? null,
        stock ?? null,
        categoryId,
        image_url ?? null,
        sku ?? null,
        is_active ?? null,
        req.params.id
      ]
    );

    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);
    res.status(500).json({ error: "Erro ao atualizar produto." });
  } finally {
    client.release();
  }
}
