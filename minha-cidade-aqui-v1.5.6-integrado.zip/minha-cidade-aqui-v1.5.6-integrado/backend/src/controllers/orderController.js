import { pool } from "../config/db.js";

export async function createOrder(req, res) {
  const client = await pool.connect();

  try {
    const {
      items,
      fulfillment_type = "delivery",
      delivery_address,
      payment_method = "pix",
      delivery_fee = 0,
      notes
    } = req.body;

    if (!Array.isArray(items) || !items.length) {
      return res.status(400).json({ error: "O pedido precisa ter itens." });
    }

    if (!["delivery", "pickup"].includes(fulfillment_type)) {
      return res.status(400).json({ error: "Tipo de recebimento inválido." });
    }

    if (fulfillment_type === "delivery" && !delivery_address) {
      return res.status(400).json({ error: "Endereço de entrega é obrigatório." });
    }

    await client.query("BEGIN");

    let subtotal = 0;
    const checkedItems = [];

    for (const item of items) {
      const product = await client.query(
        `SELECT p.id, p.store_id, p.name, p.price, p.stock
         FROM products p
         JOIN stores s ON s.id = p.store_id
         WHERE p.id = $1
           AND p.is_active = TRUE
           AND s.is_active = TRUE
         FOR UPDATE OF p`,
        [item.product_id]
      );

      if (!product.rowCount) throw new Error(`Produto ${item.product_id} não encontrado.`);

      const p = product.rows[0];
      const qty = Number(item.quantity);

      if (!Number.isInteger(qty) || qty <= 0) throw new Error("Quantidade inválida.");
      if (p.stock < qty) throw new Error(`Estoque insuficiente para ${p.name}.`);

      subtotal += Number(p.price) * qty;
      checkedItems.push({ ...p, quantity: qty });
    }

    const storeIds = [...new Set(checkedItems.map(i => i.store_id))];
    if (storeIds.length !== 1) {
      throw new Error("Cada pedido deve conter produtos de apenas uma loja.");
    }

    const fee = fulfillment_type === "delivery" ? Number(delivery_fee || 0) : 0;
    const total = subtotal + fee;

    const order = await client.query(
      `INSERT INTO orders
       (customer_user_id, store_id, status, fulfillment_type,
        delivery_address, payment_method, payment_status,
        subtotal, delivery_fee, total, notes)
       VALUES ($1,$2,'pending',$3,$4,$5,'pending',$6,$7,$8,$9)
       RETURNING *`,
      [
        req.user.id,
        storeIds[0],
        fulfillment_type,
        fulfillment_type === "delivery" ? delivery_address : null,
        payment_method,
        subtotal.toFixed(2),
        fee.toFixed(2),
        total.toFixed(2),
        notes || null
      ]
    );

    for (const item of checkedItems) {
      await client.query(
        `INSERT INTO order_items
         (order_id, product_id, product_name, unit_price, quantity)
         VALUES ($1,$2,$3,$4,$5)`,
        [order.rows[0].id, item.id, item.name, item.price, item.quantity]
      );

      await client.query(
        "UPDATE products SET stock = stock - $1 WHERE id = $2",
        [item.quantity, item.id]
      );
    }

    await client.query("COMMIT");
    res.status(201).json(order.rows[0]);
  } catch (error) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: error.message || "Erro ao criar pedido." });
  } finally {
    client.release();
  }
}

export async function myOrders(req, res) {
  try {
    const result = await pool.query(
      `SELECT o.*, s.name AS store_name, d.name AS driver_name,
              COALESCE((SELECT json_agg(json_build_object(
                'product_id', oi.product_id,
                'product_name', oi.product_name,
                'unit_price', oi.unit_price,
                'quantity', oi.quantity,
                'line_total', oi.line_total
              ) ORDER BY oi.product_name) FROM order_items oi WHERE oi.order_id = o.id), '[]'::json) AS items
       FROM orders o
       JOIN stores s ON s.id = o.store_id
       LEFT JOIN users d ON d.id = o.driver_user_id
       WHERE o.customer_user_id = $1
       ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar pedidos." });
  }
}

export async function merchantOrders(req, res) {
  try {
    const result = await pool.query(
      `SELECT o.*, s.name AS store_name, u.name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
              d.name AS driver_name, d.phone AS driver_phone,
              COALESCE((SELECT json_agg(json_build_object(
                'product_id', oi.product_id,
                'product_name', oi.product_name,
                'unit_price', oi.unit_price,
                'quantity', oi.quantity
              ) ORDER BY oi.created_at) FROM order_items oi WHERE oi.order_id = o.id), '[]'::json) AS items
       FROM orders o
       JOIN stores s ON s.id = o.store_id
       JOIN users u ON u.id = o.customer_user_id
       LEFT JOIN users d ON d.id = o.driver_user_id
       WHERE s.owner_user_id = $1
       ORDER BY o.created_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar pedidos do lojista." });
  }
}

export async function updateOrderStatus(req, res) {
  try {
    const { status, cancellation_reason, delivery_fee } = req.body;
    const transitions = {
      pending: ["confirmed", "cancelled"],
      confirmed: ["preparing", "cancelled"],
      preparing: ["ready", "cancelled"],
      ready: ["awaiting_driver", "completed", "cancelled"],
      awaiting_driver: ["cancelled"]
    };

    const current = await pool.query(
      `SELECT o.status, o.fulfillment_type, o.subtotal, o.delivery_fee FROM orders o JOIN stores s ON s.id=o.store_id
       WHERE o.id=$1 AND s.owner_user_id=$2`, [req.params.id, req.user.id]
    );
    if (!current.rowCount) return res.status(404).json({ error: "Pedido não encontrado." });
    if (!(transitions[current.rows[0].status] || []).includes(status)) {
      return res.status(400).json({ error: `Mudança de status não permitida: ${current.rows[0].status} → ${status}.` });
    }
    if (status === "cancelled" && !String(cancellation_reason || "").trim()) {
      return res.status(400).json({ error: "Informe o motivo do cancelamento." });
    }

    const currentOrder = current.rows[0];
    let acceptedDeliveryFee = null;

    // Ao aceitar um pedido para entrega, o lojista define a taxa conforme o raio/distância.
    // Usa as colunas já existentes (delivery_fee e total), sem alterar a estrutura do banco.
    if (currentOrder.status === "pending" && status === "confirmed") {
      if (currentOrder.fulfillment_type === "delivery") {
        if (delivery_fee === undefined || delivery_fee === null || String(delivery_fee).trim() === "") {
          return res.status(400).json({ error: "Informe a taxa de entrega antes de aceitar o pedido." });
        }
        acceptedDeliveryFee = Number(delivery_fee);
        if (!Number.isFinite(acceptedDeliveryFee) || acceptedDeliveryFee < 0) {
          return res.status(400).json({ error: "Taxa de entrega inválida." });
        }
      } else {
        acceptedDeliveryFee = 0;
      }
    }

    const result = await pool.query(
      `UPDATE orders o
       SET status = $1,
           delivery_fee = CASE WHEN $5::numeric IS NOT NULL THEN $5::numeric ELSE o.delivery_fee END,
           total = CASE WHEN $5::numeric IS NOT NULL THEN o.subtotal + $5::numeric ELSE o.total END,
           notes = CASE WHEN $4::text IS NOT NULL THEN CONCAT(COALESCE(o.notes || E'\n',''), 'Cancelamento: ', $4) ELSE o.notes END
       FROM stores s
       WHERE o.id = $2
         AND o.store_id = s.id
         AND s.owner_user_id = $3
       RETURNING o.*`,
      [status, req.params.id, req.user.id, status === "cancelled" ? String(cancellation_reason).trim() : null, acceptedDeliveryFee]
    );

    if (!result.rowCount) return res.status(404).json({ error: "Pedido não encontrado." });
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao atualizar status do pedido." });
  }
}


export async function availableDriverOrders(req, res) {
  try {
    const result = await pool.query(
      `SELECT o.*, s.name AS store_name, s.city AS store_city, s.state AS store_state,
              u.name AS customer_name,
              COALESCE((SELECT json_agg(json_build_object(
                'product_id', oi.product_id,
                'product_name', oi.product_name,
                'unit_price', oi.unit_price,
                'quantity', oi.quantity,
                'line_total', oi.line_total
              ) ORDER BY oi.created_at) FROM order_items oi WHERE oi.order_id = o.id), '[]'::json) AS items
       FROM orders o
       JOIN stores s ON s.id = o.store_id
       JOIN users u ON u.id = o.customer_user_id
       WHERE o.fulfillment_type = 'delivery'
         AND o.status = 'awaiting_driver'
         AND o.driver_user_id IS NULL
       ORDER BY o.created_at ASC`,
      []
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar entregas disponíveis." });
  }
}

export async function myDriverOrders(req, res) {
  try {
    const result = await pool.query(
      `SELECT o.*, s.name AS store_name, s.city AS store_city, s.state AS store_state,
              u.name AS customer_name, u.phone AS customer_phone,
              COALESCE((SELECT json_agg(json_build_object(
                'product_id', oi.product_id,
                'product_name', oi.product_name,
                'unit_price', oi.unit_price,
                'quantity', oi.quantity,
                'line_total', oi.line_total
              ) ORDER BY oi.created_at) FROM order_items oi WHERE oi.order_id = o.id), '[]'::json) AS items
       FROM orders o
       JOIN stores s ON s.id = o.store_id
       JOIN users u ON u.id = o.customer_user_id
       WHERE o.driver_user_id = $1
       ORDER BY CASE WHEN o.status = 'completed' THEN 1 ELSE 0 END, o.updated_at DESC`,
      [req.user.id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao consultar entregas do entregador." });
  }
}

export async function acceptDriverOrder(req, res) {
  try {
    const result = await pool.query(
      `UPDATE orders
       SET driver_user_id = $1,
           status = 'accepted_by_driver'
       WHERE id = $2
         AND fulfillment_type = 'delivery'
         AND status = 'awaiting_driver'
         AND driver_user_id IS NULL
       RETURNING *`,
      [req.user.id, req.params.id]
    );

    if (!result.rowCount) {
      return res.status(409).json({ error: "Esta entrega não está mais disponível." });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao aceitar entrega." });
  }
}

export async function updateDriverOrderStatus(req, res) {
  try {
    const { status } = req.body;
    const transitions = {
      accepted_by_driver: ["picked_up"],
      picked_up: ["out_for_delivery"],
      out_for_delivery: ["completed"]
    };

    const current = await pool.query(
      `SELECT id, status FROM orders WHERE id = $1 AND driver_user_id = $2`,
      [req.params.id, req.user.id]
    );
    if (!current.rowCount) return res.status(404).json({ error: "Entrega não encontrada para este entregador." });

    const currentStatus = current.rows[0].status;
    if (!(transitions[currentStatus] || []).includes(status)) {
      return res.status(400).json({ error: `Mudança de status não permitida: ${currentStatus} → ${status}.` });
    }

    const result = await pool.query(
      `UPDATE orders SET status = $1 WHERE id = $2 AND driver_user_id = $3 RETURNING *`,
      [status, req.params.id, req.user.id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erro ao atualizar etapa da entrega." });
  }
}
